history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
loadkeys us
clear
ls /usr/share/keymaps/i386/qwerty/
loadkeys /usr/share/keymaps/i386/qwerty/us.map.gz
clear
apt update
clear
echo TPServer > /etc/hostname
reboot
clear
apt update
clear
apt install kbd console-setup keyboard-configuration
dpkg-reconfigure keyboard-configuration
setupcon
reboot
clear
apt full-upgrade
apt upgrade
apt update
apt full-upgrade
dpkg --configure -a 
clear
reboot
clear
ls
ls -l
clear
rm -rf /root/Material_Adicional_TPVMCA
rm -rm -rf /root/Archivos/Material_Adicional_TPVMCA
rm -rf /root/Archivos/Material_Adicional_TPVMCA
ls -l /root/Archivos
ls -lh /root
tar -trf /root/Material_Adicional_TPVMCA.tar.gz
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -c /root
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -lh /root
mv /root/Material_Adicional_TPVMCA /root/Archivos
ls -lh /root/Archivos
clear
cd /Archivos
cd /
cd /Archivos
ls -s
ls
clear
cd
 d
ls -l /root/Archivos
clear
cd
cd /root/Archivos
clear
ls
cat /root/Archivos/calve_publica.pub >/root/.ssh/authorized_keys
cat /root/Archivos/clave_publica.pub >/root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
clear
cd
clear
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
celar
clear
reboot
clear
systemctl restar ssh
systemctl restart ssh
systemctl status ssh
clear
vi /etc/network/interfaces
reboot
ls -l
clear
exit
exit
clear
exit
clear
apt update
clear
apache2 -v
clear
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzvf /root/Material_Adicional_TPVMCA.tar.gz -C /root
mv Material_Adicional_TPVMCA Archivos
ls -l /www_dir
ls /www_dir
ls -l
cd /root/Archivos
ls -l
clear
systemctl status apache2
clear
apt install mariadb-server
clear
cd
clear
systemctl status mariadb
celaer
clear
mysql – u root
clear
mysql – u root
clear
mariadb
CLEAR
clear
mysql -u root
clear
mysql -u root empresa < /root/Archivos/db.sql
mysql -u root empresa < /root/Archivos/db.sql
clear
mysql -u root -e "CREATE DATABASE empresa;"
mysql -u root empresa < /root/Archivos/db.sql
mysql -u root
clear
ip a
ping -c 4 192.168.100.1
ping -c 4 google.com
clear
ping -c google.com
ping -c 4 google.com
ping -c 4 192.168.100.1
clear
ip a
clae
clear
apt update
clear
apt install apache2
apt install php libapache2-mod-php
clear
apache -v
apache2 -v
clear
mysql -u root
clear
poweroff
clear
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
clear
mkdir /www_dir
vi /etc/fstab
mkdir /backup_dir
vi /etc/fstab
clear
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
celar
clear
cd /opt/scripts
vi /opt/scripts/backup_full.sh
cd
chmod +x /opt/scripts/backup_full.sh
mkdir -p /opt/scripts
chmod +x /opt/scripts/backup_full.sh
cd /opt/scripts
chmod +x /opt/scripts/backup_full.sh
exit
